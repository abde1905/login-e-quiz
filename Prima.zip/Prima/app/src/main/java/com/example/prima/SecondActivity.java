package com.example.prima;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class SecondActivity  extends AppCompatActivity {

    int b1;
    int b2;
    int b4;
    int bg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        MaterialButton primo = (MaterialButton) findViewById(R.id.primo);
        MaterialButton secondo = (MaterialButton) findViewById(R.id.secondo);
        MaterialButton giusto = (MaterialButton) findViewById(R.id.giusta);
        MaterialButton quarto = (MaterialButton) findViewById(R.id.quarto);
        MaterialButton invia = (MaterialButton) findViewById(R.id.invia);

        primo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               b1=1;
            }
        });

        secondo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b2=1;
            }
        });

        giusto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bg=1;
            }
        });

        quarto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b4=1;
            }
        });

        invia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(bg==1) {
                    lanciatost("risposta giusta");
                } else{
                    lanciatost("risposta sbagliata");
                }

            }
        });

    }

    protected void lanciatost (String testo){
        Toast toast = Toast.makeText(getApplicationContext(), testo, Toast.LENGTH_LONG);
        toast.show();

    }
}
