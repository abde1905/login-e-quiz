package com.example.prima;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.prima.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String utente = "ciao";
        String pass = "ciao";

        EditText username = (EditText) findViewById(R.id.username);

        EditText password = (EditText) findViewById(R.id.password);

        TextView secondo = (TextView) findViewById(R.id.login_text_1);

        MaterialButton button = (MaterialButton) findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String u = username.getText().toString();
                String p = password.getText().toString();
                System.out.println("username: " + u);
                System.out.println("password: " + p);
                if(utente.equals(u)){
                    if(pass.equals(p)){
                        String valore = "successo";
                        lanciatost(valore);
                        Intent myIntent = new Intent(MainActivity.this, SecondActivity.class);
                        startActivity(myIntent);
                    }else{
                        password.setText(" ");
                        String valore = "non successo";
                        lanciatost(valore);
                    }

                }else{
                    String valore = "Login non corretto";
                    lanciatost(valore);
                }

            }
        });

    }

    protected void lanciatost (String testo){
        Toast toast = Toast.makeText(getApplicationContext(), testo, Toast.LENGTH_LONG);
        toast.show();


    }

}